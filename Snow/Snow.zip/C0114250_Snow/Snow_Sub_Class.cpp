#include "Snow_Sub_Class.h"
#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <cstdio>
#define pi 3.141592
#define g 9.80665
#define e 2.71828
#include <time.h>
#include <thread>

Snow_Sub_Class::Snow_Sub_Class()
{

	atm = 9.86923264705882 * pow(10, -6);
	vt = 0;
	takasa = 0;
	thetaX = 0;
	thetaZ = 0;
	X = 0;
	Z = 0;
	lastX = 0;
	lastZ = 0;
	lengthX = 0.0;
	lengthZ = 0;
	Time = 0;
	v = 0;
	TURNX = 0;
	TURNZ = 0;
	theta = 0.0;
	sita = 0;
	tn = 0;
	xAngle = 0.0;
	yAngle = 0.0;
	Pa = 0;
	countTime = 0;
	t = 0;
	endTime = 0;
	startTime = 0;
	k = 0;
	BF = 0;
	start = 0;
	START = 0;
	ncount = 0;
	N1 = 2000;
	N2 = 2000;
	rcount = 0;
	yStart; zAngle = 0;
	Xlocation = 0;
	Ylocation = 0;
	huuryoku = 200;


	//�����ϐ�
	ho = 200;    //�����ʒu[m]
	t0 = 5;  //�n��̉��x[��]
	R = 0.005;  //���̂̔��a[m]
	m = 0.0005;  //����[kg]


}




Snow_Sub_Class::~Snow_Sub_Class()
{


}

void Snow_Sub_Class::calc()
{
	double B1 = 3, B2 = 3;
	startTime = glutGet(GLUT_ELAPSED_TIME);
	double to = 0, kaku = 0, kiatu;
	theta = fmod(theta + 0.3, 360.0);
	sita = theta*pi / 180;

	if (sin(sita)>0) {
		tn = sin(sita);
	}
	else {
		tn = 0;
	}
	if (start == 1) {
		TURNX += BF;
		tn -= 0.5;
	}
	else if (start == 2) {
		TURNX -= BF;
		tn -= 0.5;
	}
	else if (start == 3) {
		TURNZ += BF;
		tn -= 0.5;
	}
	else if (start == 4) {
		TURNZ -= BF;
		tn -= 0.5;
	}
	t = t0 - 0.0065*takasa + tn;
	Time = startTime - endTime;
	takasa = h - vt;
	if (takasa > 0) {
		thetaX = fmod(thetaX + rand() % N1 / 700, 360.0);
		thetaZ = fmod(thetaZ + rand() % N2 / 700, 360.0);
		lengthX = sin(thetaX * pi / 180) *B1;
		lengthZ = cos(thetaZ * pi / 180) *B2;
		Pa = 991.68 * 100 * pow((1 - 0.0065*takasa / (t + 272.479564032697)), (5.258));
		kiatu = Pa * atm;
		k = (pow(R, 2)*kiatu) / (t + 272.479564032697)*pow(0.00361391270624754, -1);
		v = sqrt((m*g) / k)*tanh((Time / 1000) / sqrt(m / (g*k)));
		vt = v*Time / 1000;
		countTime = sqrt(m / (g*k))*acosh(pow(e, ((takasa*k) / m)));
		
	}
	if (start == 5) {
		BF = 0;
		tn = 0;
	}
	else {
		BF = (rand() % huuryoku);
		BF = BF / 15000;
	}
}

void Snow_Sub_Class::Debug(){
	ncount++;
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("�o�ߎ���:%d[�b]\n", (int)(Time / 1000));
		printf("���݂̋C��:%.2f[��]\n", t);
		printf("���݂̋C��:%.2f[hPa]\n", Pa / 100);
		printf("���݂̑���:%.2f[m/s]\n", v);
		printf("��C��RF:%.2f�~10^(-4)[N]\n", k * 10000 * v);
		printf("���z���M:%.2f[��]\n", tn);
		printf("���݂̍���:%.2f[m]\n", takasa);
		printf("���݂�x���W:%.2f[m]\n", lastX);
		printf("���݂�z���W:%.2f[m]\n", lastZ);
		printf("�����܂ł̎���:%d[�b]\n", (int)countTime);
		printf("==============================================\n");
		printf("�U��X:%d\n", N1 / 10);
		printf("�U��Z:%d\n", N2 / 10);
		printf("���̓��x��:%d���x��\n", huuryoku/1000);
		if (start == 1) {
			printf("�����F��\n");
		}
		else if (start == 2) {
			printf("����:��\n");
		}
		else if (start == 3) {
			printf("����:��\n");
		}
		else if (start == 4) {
			printf("����:�k\n");
		}
		else {
			printf("����:��\n");
		}
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		ncount = 0;
}

void Snow_Sub_Class::draw()
{
	float diffuse_gold[] = { 4.0, 5, 5, 5 };
	float specular_gold[] = { 4.0, 5, 5, 5 };
	float ambient_gold[] = { 4.0, 5, 5, 5 };
	float shininess_gold = 1;
	glRotated(20, 90, 180, 20);
	if (takasa >= (h - 0.1)) {
		glTranslatef(X, -45 + takasa, Z);
		glutSolidSphere(R * 70, 100, 100);
	}
	else if (takasa < (h - 0.1) && takasa >= 0.1) {
		glTranslatef(X + (lengthX / 3) + TURNX - k*v, -45 + takasa, Z + (lengthZ / 3) + TURNZ - k*v);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse_gold);
		glMaterialfv(GL_FRONT, GL_SPECULAR, specular_gold);
		glMaterialfv(GL_FRONT, GL_AMBIENT, ambient_gold);
		glMaterialf(GL_FRONT, GL_SHININESS, shininess_gold);
		glEnable(GL_LIGHTING);
		glutSolidSphere(R * 70, 100, 100);
		glDisable(GL_LIGHTING);
		lastX = X + (lengthX / 3) + TURNX - k*v;
		lastZ = Z + (lengthZ / 3) + TURNZ - k*v;
	}
	else if (takasa < 0.1) {


		if (lastZ < (-40)) {
			vt = h;
			glTranslatef(lastX, -44 + takasa, lastZ);
			glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse_gold);
			glMaterialfv(GL_FRONT, GL_SPECULAR, specular_gold);
			glMaterialfv(GL_FRONT, GL_AMBIENT, ambient_gold);
			glMaterialf(GL_FRONT, GL_SHININESS, shininess_gold);
			glutSolidSphere(R * 70, 100, 100);
			v = 0;
		}
		else {
			vt = h;
			glTranslatef(lastX, -44 + takasa, lastZ);
			glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse_gold);
			glMaterialfv(GL_FRONT, GL_SPECULAR, specular_gold);
			glMaterialfv(GL_FRONT, GL_AMBIENT, ambient_gold);
			glMaterialf(GL_FRONT, GL_SHININESS, shininess_gold);
			glutSolidSphere(R * 70, 100, 100);
			v = 0;
		}
	}
}