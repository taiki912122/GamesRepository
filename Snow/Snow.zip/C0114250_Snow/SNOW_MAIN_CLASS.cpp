﻿
#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <cstdio>
#include <time.h>
#include <thread>
#define KEY_ESC 27
#define pi 3.141592
#define g 9.80665
#define e 2.71828
#include "stdafx.h"

#include "Snow_Sub_Class.h"
#define PERTICLE_COUNT 200

#define KEY_ESC 27
#define pi 3.141592
#define g 9.80665
#define e 2.71828
#define imageWidth 128
#define imageHeight 128
#define imageWidth2 128
#define imageHeight2 128

unsigned char mouseFlag = GL_FALSE;
unsigned char texImage[imageHeight][imageWidth][3];
unsigned char texImage2[imageHeight2][imageWidth2][3];
using namespace std;
const int N = 10;
int hairetu;


double atm = 9.86923264705882*pow(10, -6);
double h, vt = 0, takasa = 0, thetaX = 0, thetaZ = 0, X = 0, Z = 0, lastX = 0, lastZ = 0, lengthX = 0.0, lengthZ = 0, Time = 0, v = 0, TURNX = 0, TURNZ = 0;
double theta = 0.0, sita = 0, tn = 0, xAngle = 0.0, yAngle = 0.0, Pa = 0, countTime = 0, t = 0, endTime = 0, startTime = 0, k = 0, BF = 0;
int start = 0, START = 0, ncount = 0, N1 = 2000, N2 = 2000, rcount = 0, xStart, yStart, zAngle = 0, Xlocation = 0, Ylocation = 0, huuryoku = 200;


//調整変数
double ho = 200;    //初期位置[m]
double t0 = 5;  //地上の温度[℃]
double R = 0.005;  //物体の半径[m]
double m = 0.0005;  //質量[kg]


Snow_Sub_Class*SnowSub;


//ファイル読み込み
void readRAWImage2(char* filename2)
{
	FILE *fp2;

	if (fopen_s(&fp2, filename2, "r")) {
		exit(1);
	}

	fread(texImage2, 1, imageWidth2*imageHeight2 * 3, fp2);
	fclose(fp2);
}

void readRAWImage(char* filename)
{
	FILE *fp;
	if (fopen_s(&fp, filename, "r")) {
		fprintf(stderr, "Cannot open raw file %s¥n", filename);
		exit(1);
	}
	fread(texImage, 1, imageWidth*imageHeight * 3, fp); // read RGB data
	fclose(fp);
}

//キーボード入力
void myKeyboard(unsigned char key, int x, int y) {
	switch (key) {
	case 'w':
		
			N2 += 1000;
			if (N2 == 11000) {
				N2 -= 1000;
			}
			for (int i = 0; i < PERTICLE_COUNT; i++)
			{
			SnowSub[i].keyW(N2);
		}
		glutPostRedisplay();
		break;
	case 's':
		
			N2 -= 1000;
			if (N2 == 0) {
				N2 += 1000;
			}
			for (int i = 0; i < PERTICLE_COUNT; i++)
			{
			SnowSub[i].keyS(N2);
		}
		glutPostRedisplay();
		break;
	case 'd':
		
			N1 += 1000;
			if (N1 == 11000) {
				N1 -= 1000;
			}
			for (int i = 0; i < PERTICLE_COUNT; i++)
			{
			SnowSub[i].keyD(N1);
		}
		glutPostRedisplay();
		break;
	case 'a':
		
			N1 -= 1000;
			if (N1 == 0) {
				N1 += 1000;
			}
			for (int i = 0; i < PERTICLE_COUNT; i++)
			{
			SnowSub[i].keyA(N1);
		}
		glutPostRedisplay();
		break;


	case 'x':
		
			huuryoku += 1000;
			if (huuryoku == 11000) {
				huuryoku -= 1000;
			}
			for (int i = 0; i < PERTICLE_COUNT; i++)
			{

			SnowSub[i].keyX(huuryoku);
		}
		break;
	case 'z':
		

			huuryoku -= 1000;
			if (huuryoku ==0) {
				huuryoku += 1000;
			}
			for (int i = 0; i < PERTICLE_COUNT; i++)
			{
			SnowSub[i].keyZ(huuryoku);
		}
		break;
	case 'c':
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
			start = 5;
			SnowSub[i].keyC(start);
		}
		break;
	case '@':
		
			zAngle += 2;
			if (zAngle == 402) {
				zAngle -= 2;
			}
			
		break;
	case ':':
		zAngle -= 2;
		if (zAngle == -402) {
			zAngle += 2;
		}
		break;
	case ']':
		Xlocation -= 2;
		if (Xlocation == -402) {
			Xlocation += 2;
		}
		break;
	case 'r':
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
		endTime = startTime;
		vt = 0;
		X = rand() % 150 - 75;
		Z = rand() % 150 - 75;
		h = rand() % 1000 + ho;
		TURNX = 0;
		TURNZ = 0;
		v = 0;
		
			SnowSub[i].keyR(endTime,startTime,vt,X,Z,h,TURNX,TURNZ,v);
		}
		break;
	case ';':
		Xlocation += 2;
		if (Xlocation == 402) {
			Xlocation -= 2;
		}
		break;
	case KEY_ESC:
		exit(0);
	}
}

//キーボード入力
void mySpecialKeyboard(int key, int x, int y) {

	switch (key) {
	case GLUT_KEY_RIGHT:
		start = 1;
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
			SnowSub[i].keyZ(start);
		}
		glutPostRedisplay();
		break;
	case GLUT_KEY_LEFT:
		start = 2;
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
			SnowSub[i].keyZ(start);
		}
		glutPostRedisplay();
		break;
	case GLUT_KEY_UP:
		start = 4;
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
			SnowSub[i].keyZ(start);
		}
		glutPostRedisplay();
		break;
	case GLUT_KEY_DOWN:
		start = 3;
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
			SnowSub[i].keyZ(start);
		}
		glutPostRedisplay();
		break;
	case GLUT_KEY_F1:
		START = 1;
		for (int i = 0; i < PERTICLE_COUNT; i++)
		{
			SnowSub[i].keyZ(start);
		}
		glutPostRedisplay();
		break;
	}
}

void mySky() {
	double s1 = 1, q1 = 1;
	glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, imageWidth2, imageHeight2, 1, GL_RGB, GL_UNSIGNED_BYTE, texImage);
	glRotated(20, 90, 180, 20);
	glTranslatef(0, 100, 0);
	glBegin(GL_QUADS);
	for (int i = -128; i <= 128; i++) {
		glTexCoord2d(0.0, 0.0); glVertex3i(i, 0, -128);
		glTexCoord2d(s1, 0.0);  glVertex3i(i, 0, 128);
		glTexCoord2d(s1, q1);  glVertex3i(-128, 0, i);
		glTexCoord2d(0.0, q1);   glVertex3i(128, 0, i);
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

void myfloar() {
	double s = 5, q = 5;
	glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, imageWidth, imageHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, texImage2);
	glTranslatef(0, -45, 0);
	glRotated(20, 90, 180, 20);
	glBegin(GL_QUADS);
	for (int i = -80; i <= 80; i++) {
		glTexCoord2d(0.0, 0.0); glVertex3i(i, 0, -80);
		glTexCoord2d(s, 0.0);  glVertex3i(i, 0, 80);
		glTexCoord2d(s, q);  glVertex3i(-80, 0, i);
		glTexCoord2d(0.0, q);   glVertex3i(80, 0, i);
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

void myLight() {
	GLfloat light0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light1[] = { 0.0, 2.0, 1.0, 1.0 };
	GLfloat spotDirection[] = { 0.0, -1.0, -0.5 };
	//GLfloat whiteDiffuse[] = { 1.0, 1.0, 1.0, 1.0 };
	//GLfloat redDiffuse[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat greenDiffuse[] = { 0.4, 1.0, 0.3, 0.5 };
	GLfloat whiteSpecular[] = { 1.0, 1.0, 1.0, 1.0 };
	//GLfloat redAmbient[] = { 1, 1, 1, 1.0 };
	GLfloat whiteAmbient[] = { 0.1, 0.1, 0.1, 1.0 };

	glLightfv(GL_LIGHT1, GL_POSITION, light1);
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotDirection);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, sin(sita) * 40 + 30);
	glLightfv(GL_LIGHT0, GL_POSITION, light0);
	glEnable(GL_DEPTH_TEST);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, greenDiffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, whiteSpecular);
	glMaterialfv(GL_FRONT, GL_AMBIENT, whiteAmbient);
	glMaterialf(GL_FRONT, GL_SHININESS, 128.0);
	glEnable(GL_LIGHTING);
}


void myAngle() {
	glTranslated(Xlocation, Ylocation, zAngle);
	glRotated(xAngle, 1.0, 0.0, 0.0);
	glRotated(yAngle, 0.0, 1.0, 0.0);
}


void setData() {
	ncount++;
	if (ncount > 100) {
	/*	printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("経過時間:%d[秒]\n", (int)(Time / 1000));
		printf("現在の気温:%.2f[℃]\n", t);
		printf("現在の気圧:%.2f[hPa]\n", Pa / 100);
		printf("現在の速さ:%.2f[m/s]\n", v);
		printf("空気抵抗F:%.2f×10^(-4)[N]\n", k * 10000 * v);
		printf("太陽光熱:%.2f[℃]\n", tn);
		printf("現在の高さ:%.2f[m]\n", takasa);
		printf("現在のx座標:%.2f[m]\n", lastX);
		printf("現在のz座標:%.2f[m]\n", lastZ);
		printf("落下までの時刻:%d[秒]\n", (int)countTime);
		printf("==============================================\n");
		printf("振幅X:%d\n", N1 / 2);
		printf("振幅Z:%d\n", N2 / 2);
		printf("風力レベル:%dレベル\n", huuryoku / 200);
		if (start == 1) {
			printf("風向：東\n");
		}
		else if (start == 2) {
			printf("風向:西\n");
		}
		else if (start == 3) {
			printf("風向:南\n");
		}
		else if (start == 4) {
			printf("風向:北\n");
		}
		else {
			printf("風向:無\n");
		}
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		printf("***********************************************\n");
		ncount = 0;*/
	}
}


//描画関数
void display() {
	int i, j;
	float x0, y0;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPushMatrix();
	myAngle();
	glPushMatrix();
	mySky();
	glPopMatrix();
	glPushMatrix();
	myLight();
	glPopMatrix();
	glPushMatrix();
	myfloar();
	glPopMatrix();
	for (int i = 0; i < PERTICLE_COUNT; i++)
	{
		glPushMatrix();
		glEnable(GL_LIGHTING);
		SnowSub[i].draw();
		glPopMatrix();
		glDisable(GL_LIGHTING);
	}


	glPushMatrix();
	for (i = -100; i < 100; i++) {
		x0 = 0.04 * (float)i;
		glNormal3f(0.0, 0.0, 1.0);
		for (j = -100; j < 100; j++) {
			y0 = 0.04 * (float)j;
			glVertex3f(x0, y0, 0.0);
			glVertex3f(x0 + 0.04, y0, 0.0);
		}
	}
	glPopMatrix();
	glPopMatrix();
	glDisable(GL_DEPTH_TEST);
	glutSwapBuffers();
	glFlush();
	setData();
}

void myMouseMotion(int x, int y)
{
	int xdis, ydis;
	double a = 0.5;

	if (mouseFlag == GL_FALSE)
		return;
	xdis = x - xStart;
	ydis = y - yStart;

	xAngle += (double)ydis*a;
	yAngle += (double)xdis*a;

	xStart = x;
	yStart = y;
	glutPostRedisplay();
}


void myMouseFunc(int button, int state,
	int x, int y)
{
	if (button == GLUT_LEFT_BUTTON
		&& state == GLUT_DOWN) {
		xStart = x;
		yStart = y;
		mouseFlag = GL_TRUE;
	}
	else {
		mouseFlag = GL_FALSE;
	}
}


void initLighting(void)
{
	GLfloat  light0_diffuse[] = { 1, 0.5, 0.5, 1.0 };
	GLfloat  light0_specular[] = { 1, 0.2, 0.2, 1.0 };
	GLfloat  light1_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat  light1_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat spotDir[] = { -40, 0, 100 };
	GLfloat  spot_exp = 0.0;

	glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light0_specular);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
	glLightfv(GL_LIGHT1, GL_SPECULAR, light1_specular);
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotDir);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, spot_exp);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, sin(sita) * 40 + 30);

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
}


void myReshape(int width, int height)
{
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (double)width / (double)height, 0.1, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslated(0.0, 0.0, -3.6);
}


//計算
void idle() {

	for (int i = 0; i < PERTICLE_COUNT; i++)
	{
		SnowSub[i].calc();
	}
	glutPostRedisplay();
	SnowSub[0].Debug();
}

//設定
void myInit(char *progname) {
	int width = 1000, height = 750;
	double aspect = (double)width / (double)height;
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_SINGLE);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(0, 0);
	glutCreateWindow(progname);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glEnable(GL_DEPTH_TEST);
	glutKeyboardFunc(myKeyboard);
	glutSpecialFunc(mySpecialKeyboard);
	glutMouseFunc(myMouseFunc);
	glutMotionFunc(myMouseMotion);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, aspect, 1.0, 1000.0);
	gluLookAt(0.0, 1.0, 200.0 + zAngle, 0.0, 10.0, 0.0, 0.0, 0.0, 100.0);
	glMatrixMode(GL_MODELVIEW);
	glShadeModel(GL_SMOOTH);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	readRAWImage("C0114250_2.raw");
	readRAWImage2("C0114250_1.raw");
	initLighting();
	glEnable(GL_LIGHT0);

	srand(time(NULL));
	SnowSub = new Snow_Sub_Class[PERTICLE_COUNT];
	for (int i = 0; i < PERTICLE_COUNT; i++)
	{
		X = rand() % 150 - 75;
		Z = rand() % 150 - 75;
		h = rand() % 1000 + ho;

		SnowSub[i].setXZh(X, Z, h);
	}
}

//main関数
int main(int argc, char *argv[]) {

	glutInit(&argc, argv);
	myInit(argv[0]);
	glutDisplayFunc(display);
	glutIdleFunc(idle);

	glutMainLoop();

	delete[] SnowSub;

	return 0;
}