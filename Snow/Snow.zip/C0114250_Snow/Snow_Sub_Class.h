#pragma once
#include "stdafx.h"

class Snow_Sub_Class
{
	double atm;

	double h;
	double vt;
	double takasa;
	double X;
	double Z;
	double lastX;
	double lastZ;
	double lengthX;
	double lengthZ;
	double v;
	double TURNX;
	double TURNZ;
	double k;
	double Time;
	double thetaX;
	double thetaZ;
	double t0;

	double theta;
	double sita;
	double tn;
	double xAngle;
	double yAngle;
	double Pa;
	double countTime;
	double t;
	double endTime;
	double startTime;

	double BF;
	int start;
	int START;
	int ncount;
	int N1;
	int N2;
	int rcount;
	int xStart;
	int yStart;
	int zAngle;
	int Xlocation;
	int Ylocation;
	int huuryoku;
	int ab = 0;
	double m;


	////�����ϐ�
	double R;  //���̂̔��a[m]
	double ho;


public:
	Snow_Sub_Class();
	~Snow_Sub_Class();

	void keyW(double n){
		N2 = n;
}

	void keyD(double n) {
		N1 = n;
	}
	void keyA(double n) {
		N1 = n;
	}
	void keyS(double n) {
		N2 = n;
	}
	void keyX(double n) {
		huuryoku = n;
	}
	void keyZ(double n) {
		start= n;
	}
	void keyC(double n) {
		huuryoku = n;
	}
	void keyR(double rr,double ss,double vv,double xxx,double zzz,double hhh,double turnx,double turnz,double vvv) {
		endTime = rr;
		startTime = ss;
		vt = vv;
		X = xxx;
		Z = zzz;
		h = hhh;
		TURNX = turnx;
		TURNZ = turnz;
		v = vvv;
		endTime = startTime;

	}
	void Debug();
	void draw();
	void setXZh(double xx, double zz, double hh)
	{
		X = xx;
		Z = zz;
		h = hh;
	}

	void calc();

};
