package final16b;
import robocode.*;
import java.awt.Color;
import java.awt.geom.*;
import java.util.*;


public class C0114250 extends AdvancedRobot{
    Hashtable tekiClass;			
    C0114250_danmaru teki;		
    String name="BorderGuard";
    final double BoudargardWall=40000, PI = Math.PI;
    double firePower, hanpatu = 0,kyori=0,MyE=0,wall=0;
    int count = 0,Ocount=0;	
    boolean Bourdargard=false;    

    
    public void run() {
	tekiClass = new Hashtable(); 
	teki = new C0114250_danmaru();
	teki.distance = 100000;				
	setAdjustGunForRobotTurn(true); 
	setAdjustRadarForGunTurn(true);
	turnRadarRight(360);
     
	while(true) {
	    GMove(); 				
	    FireLevel();
            Scan();
            Ocount=Other(Ocount);
	    Colorset();
	    Energy();
	    Gunturn();
	    if(kyori<1000){
		fire(firePower);
	    }
	    execute();	
	}
    }


    void GMove() {   
	double Fx = 0;
	double Fy = 0;
	double F;
	double sita;
        int w=0;
        w=(int) wall(w);
	C0114250_Gclass G;
	C0114250_danmaru z;
	Enumeration e = tekiClass.elements();
         
	while (e.hasMoreElements()) {
	    z = (C0114250_danmaru)e.nextElement();

	    if (z.live) {
		G = new C0114250_Gclass(z.x,z.y, -1000);
		F = G.power/Math.pow(getKakudo(getX(),getY(),G.x,G.y),2);
		sita = kakudoB(Math.PI/2 - Math.atan2(getY() - G.y, getX() - G.x)); 
		Fx += Math.sin(sita) * F;
		Fy += Math.cos(sita) * F;
	    }
	}
	count++;
        System.out.println("カウント数"+count);
    
	if (count > 5) {
	    count = 0;

	    if(Bourdargard==true){
		hanpatu=3000;
		System.out.println("Bordargardの反発力="+hanpatu);
	    }else{      
		hanpatu=hanpaturyoku(hanpatu);
		System.out.println(hanpatu);
	    }  
	}
	G = new C0114250_Gclass(getBattleFieldWidth()/2, getBattleFieldHeight()/2, hanpatu);
	F= G.power/Math.pow(getKakudo(getX(),getY(),G.x,G.y),1.5);
	sita= kakudoB(Math.PI/2 - Math.atan2(getY() - G.y, getX() - G.x)); 
	Fx += Math.sin(sita) * F;
	Fy += Math.cos(sita) * F;
        
	if(Bourdargard==true){
	    Fx += BoudargardWall/Math.pow(getKakudo(getX(), getY(), getBattleFieldWidth(), getY()), 2);
	    Fx -= BoudargardWall/Math.pow(getKakudo(getX(), getY(), 0, getY()), 2);
	    Fy+= BoudargardWall/Math.pow(getKakudo(getX(), getY(), getX(), getBattleFieldHeight()), 2);
	    Fy -= BoudargardWall/Math.pow(getKakudo(getX(), getY(), getX(), 0), 2);
	    System.out.println("Bourdargard");
	    aheadto(getX()-Fx,getY()-Fy);
	}else{
	    Fx += w/Math.pow(getKakudo(getX(), getY(), getBattleFieldWidth(), getY()), 3);
	    Fx -= w/Math.pow(getKakudo(getX(), getY(), 0, getY()), 3);
	    Fy += w/Math.pow(getKakudo(getX(), getY(), getX(), getBattleFieldHeight()), 3);
	    Fy -= w/Math.pow(getKakudo(getX(), getY(), getX(), 0), 3);
	    System.out.println("nothing");
	    aheadto(getX()-Fx,getY()-Fy);
	}
    }
         
     
    int turnto(double angle) {
	double kaku;
	int muki;
	kaku = kakudoB(getHeading() - angle);
	if (kaku > 90) {
	    kaku -= 180;
	    muki = -1;
        }else if (kaku < -90) {
	    kaku += 180;
	    muki = -1;
	}else {
	    muki = 1;
	}if(Ocount<2){
	    setTurnLeft(kakudoB(PI+kaku));
	}else{
	    setTurnLeft(kaku);
	}
	return muki;
    }
      
      
  public double zettaikakudo( double x,double y, double X,double Y ){
    double xj = X-x;
    double yj = Y-y;
    double m=0;
    double h = getKakudo( x,y, X,Y );
    if( xj > 0 && yj > 0 ){
	m=Math.asin( xj / h );
    }else if( xj > 0 && yj < 0 ){
	m=Math.PI - Math.asin( xj / h );
    }else if( xj < 0 && yj < 0 ){
	m=Math.PI + Math.asin( -xj / h );
    }else if( xj < 0 && yj > 0 ){
	m=2*Math.PI - Math.asin( -xj / h );
    }else{
	m=0;
    }
    return m;
}
    
    double kakudoB(double kakuB) {
	if (kakuB > PI){
	    kakuB -= 2*PI;
	}else if (kakuB < -PI){
	    kakuB += 2*PI;
	}
	return kakuB;
    }
	

    public double getKakudo( double x,double y, double X,double Y ){
	double xi = X-x;
	double yi = Y-y;
	double m = Math.sqrt( xi*xi + yi*yi );
	return m;	
    }
    
    
    double hanpaturyoku(double hanpatu) {
	if(MyE<100/3){
	    hanpatu=(Math.random()*3000)-1500;
	    System.out.println("緊急回避="+hanpatu);
	   
	}else{
	    hanpatu= (Math.random() * 2000) - 1000;
	    System.out.println("反発力="+hanpatu);
	}
	return hanpatu;
    }
    
    
    void aheadto(double x, double y) {
	double d=0;   
	double kakudo = Math.toDegrees(zettaikakudo(getX(),getY(),x,y));
	double a = turnto(kakudo);
        double Vrobot=0;
        d=hannpatukyori(d);
	BodargaurdAhead(d);
        Vrobot=(8/(kyori/100))+4;
        Vrobot=SpeedRobot(Vrobot);
        //setMaxVelocity(Vrobot);
        setAhead(d*a);
	System.out.println("進む距離="+d);
        System.out.println("速度="+Vrobot);
    }
    
     
    double hannpatukyori(double d) {
    
        if(kyori <= 100){
            d=50;
        }else if(kyori > 100 && 200 >= kyori){
            d=40;
        }else if(kyori > 200 && 400 >= kyori){
            d=35;
        }else if(kyori > 400 && 600 >=kyori){
            d=30; 
        }else if(kyori > 600 ){
            d=25;
        }
	return d;
    }
      
      
    double BodargaurdAhead(double Dicetance) {
	if(Bourdargard==true){
	    Dicetance=50;
	}else{
	    EnrgyAhead(Dicetance);
	}
	return Dicetance;
    }
    
    
    double EnrgyAhead(double Dicetance2) {
	if(MyE<100/3){
            Dicetance2=(Math.random() * 10)+30;
  
	}else{
	    hannpatukyori(Dicetance2);
            
	}
	return Dicetance2;
    }
    
    
    double SpeedRobot(double speed) {
	if(speed>8){
	    speed=8;
	}
	return speed;
    }
     
     
    void Gunturn() {
	long time = getTime() + (int)Math.round((getKakudo(getX(),getY(),teki.x,teki.y)/(20-(3*firePower))));
	Point2D.Double dw = teki.guessPosition(time);
      	double setGun = getGunHeadingRadians() - (Math.PI/2 - Math.atan2(dw.x - getY(), dw.y - getX()));
	setTurnGunLeftRadians(kakudoB(setGun));
    }
     
 
    void FireLevel() {
	firePower = 400/teki.distance;  
	if (firePower > 3) {
	    firePower = 3;
	}
        if(firePower>2.5){
	    this.setBulletColor(Color.red);
        }else if(firePower<=2.5 && firePower > 2){
	    this.setBulletColor(Color.orange);                     
        }else if(firePower <=2 && firePower > 1.5){
	    this.setBulletColor(Color.YELLOW);
        }else if(firePower <=1.5 && firePower > 1){
	    this.setBulletColor(Color.green);
        }else if(firePower <=1 && firePower > 0.5){
	    this.setBulletColor(Color.CYAN);
        }else {
	    this.setBulletColor(Color.blue);
        }     
    }
    
    
    void Scan() {
	setTurnRadarLeft(360);
    }

       
    double wall(double a) {
	if(Ocount<2){
	    a=50000;
	}else{
	    a=5000;
	}
	return a;
    }
    
    
    void Energy(){
	MyE=getEnergy();
    }
    
     
    void Colorset() {
	if(MyE<100/5){
	    this.setColors(Color.red,Color.red,Color.red);
	    this.setScanColor(Color.red);
	}else if(MyE<=100/2 && MyE>=100/5){
	    this.setColors(Color.yellow,Color.ORANGE,Color.red);
	    this.setScanColor(Color.yellow);
	}else{
	    this.setColors(Color.GREEN,Color.blue,Color.WHITE);
	    this.setScanColor(Color.green);
	}
    }
    

    int Other(int OtherCount) {
	OtherCount=getOthers();
	return OtherCount;   
    }


    public void onScannedRobot(ScannedRobotEvent event) {
	C0114250_danmaru z;
        
	if (tekiClass.containsKey(event.getName())) {
	    z = (C0114250_danmaru)tekiClass.get(event.getName());
        } else {
	    z = new C0114250_danmaru();
	    tekiClass.put(event.getName(),z);      
	}
    
	double absbearing_rad = (getHeadingRadians()+event.getBearingRadians())%(2*PI);
	z.name = event.getName();
	double h = kakudoB(event.getHeadingRadians() - z.heading);
	h = h/(event.getTime() - z.time);
	z.kakusokudo = h;
	z.x = getX()+Math.sin(absbearing_rad)*event.getDistance(); 
	z.y = getY()+Math.cos(absbearing_rad)*event.getDistance(); 
	z.bearing = event.getBearingRadians();
	z.heading = event.getHeadingRadians();
	z.time = getTime();				
	z.speed = event.getVelocity();
	z.distance = event.getDistance();	
	kyori=event.getDistance();
	z.live = true;
	if ((z.distance < teki.distance)||(teki.live == false)) {
	    teki = z;
	    if(z.name.matches(".*" + name + ".*")){
		Bourdargard=true;   
	    }else{
		Bourdargard=false;
	    }
	}
    }
  

    public void onRobotDeath(RobotDeathEvent event) {
	C0114250_danmaru z = (C0114250_danmaru)tekiClass.get(event.getName());
	z.live = false;		
    }	


    @Override
    public void onHitByBullet(HitByBulletEvent event) {
        setColors(Color.red,Color.red,Color.red);
    } 


    @Override
    public void onHitRobot(HitRobotEvent event) {
	setColors(Color.red,Color.red,Color.red);
    }


    @Override
    public void onWin(WinEvent event) {
        while(true){
            turnRight(30);
            setTurnGunRight(360);
            setTurnRadarRight(360);
            this.setScanColor(Color.PINK);
            turnLeft(30);
            execute();
        }      
    }
}