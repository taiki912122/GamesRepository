package final16b;
import java.awt.geom.Point2D;


class C0114250_danmaru {
    String name;
    public double bearing,heading,speed,x,y,distance,kakusokudo;
    public long time; 	
    public boolean live; 
    double X,Y,hankei,kaku;
    public Point2D.Double guessPosition(long jikan) {
	double yosoku = jikan - time;
	
	if(Math.abs(kakusokudo)>0){
	    hankei=speed/kakusokudo;
	    kaku=yosoku*kakusokudo;
	    Y=y + (Math.sin(heading + kaku) * hankei) - (Math.sin(heading) * hankei);
	    X = x + (Math.cos(heading) * hankei) -(Math.cos(heading + kaku) * hankei);
	}else{
	    Y = y + Math.cos(heading) * speed * yosoku;
	    X = x + Math.sin(heading) * speed * yosoku;
	}    
	return new Point2D.Double(X, Y);
    }
}