package final16b;


class C0114250_Gclass {
    public double x,y,power;
    public C0114250_Gclass(double X,double Y,double hanpatu) {
	x = X;
	y = Y;
	power = hanpatu;
    }
}  

